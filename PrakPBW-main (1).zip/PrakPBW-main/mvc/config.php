<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'projectmvc');

// BASEURL untuk memudahkan penulisan URL
define('BASEURL', 'http://localhost/PPBW_A/mvc/');