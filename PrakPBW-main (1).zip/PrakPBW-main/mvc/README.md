### LINK GOOGLE DRIVE LAPORAN

https://drive.google.com/drive/folders/1gsqPrwDivfFaspertM2t95wQ-_V3Jf-M?usp=sharing


### AKHIR LAPORAN

## Screenshot

### Halaman Home

![image](https://github.com/user-attachments/assets/14a96995-7004-47ed-9f30-f6112e2d34a4)


### Form Login

![image](https://github.com/user-attachments/assets/390b3550-d7d3-443d-bfdb-027881ecd569)


### Halaman Admin

![image](https://github.com/user-attachments/assets/a6254028-e071-42a1-b823-27e0d4a64993)


### Tambah Barang

![image](https://github.com/user-attachments/assets/ff6634df-7347-4333-befd-f71cc6f8032b)


### Edit Barang

![image](https://github.com/user-attachments/assets/63d2aac8-c8dd-4d10-b652-18e403082768)


## Kontribusi

Dibuat oleh [Dio Prasetyo_4522210148].

## Lisensi

Projek ini dilisensikan di bawah [MIT License](LICENSE
