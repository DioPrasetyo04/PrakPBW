<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="<?= BASEURL; ?>/assets/home.css">
</head>
<body>
    <div class="container">
        <h1>Selamat Datang di Aplikasi Penjualan Barang</h1>
        <p>Ini adalah halaman home.</p>
        <a href="<?= BASEURL; ?>index.php?url=login/index" class="btn">Login</a>
    </div>
</body>
</html>
